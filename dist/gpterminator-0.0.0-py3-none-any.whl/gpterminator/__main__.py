from . import GPTerminator

def main():
    app = GPTerminator.GPTerminator()
    app.run()

if __name__ == "__main__":
    main()
